package app;

public class Program {
    
    public static void main(String[] args) throws Exception {
    }
}

